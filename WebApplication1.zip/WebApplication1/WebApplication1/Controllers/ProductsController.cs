﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MassTransit;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WebApplication1.IRepository;
using WebApplication1.Models;


namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    public class ProductsController
    {
        private readonly IProductRepository _productRepository;
        private readonly IBusControl _bus;

        public ProductsController(IProductRepository productRepository,IBusControl bus)
        {
            _productRepository = productRepository;
            _bus = bus;
        }

        [HttpGet]
        public Task<string> Get()
        {
            return this.GetProduct();
        }

        private async Task<string> GetProduct()
        {
            var products = await _productRepository.Get();
            return JsonConvert.SerializeObject(products);
        }

        [HttpGet("{id}")]
        public Task<string> Get(string id)
        {
            return this.GetProductById(id);
        }

        private async Task<string> GetProductById(string id)
        {
            var products = await _productRepository.Get(id) ?? new Product();
            return JsonConvert.SerializeObject(products);
        }
        [HttpPost]
        public async Task<string> Post([FromBody] Product product)
        {
            Uri uri = new Uri("rabbitmq://localhost/product-queue");
            var endPoint = await _bus.GetSendEndpoint(uri);
            await endPoint.Send(product);
            await _productRepository.Add(product);
            return "";
        }
    }

}

﻿
using MongoDB.Driver;
using WebApplication1.Models;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace WebApplication1.IRepository
{
    public interface IProductRepository
    {
        Task<IEnumerable<Product>> Get();
        Task<Product> Get(string id);
        Task Add(Product product);
    }
}

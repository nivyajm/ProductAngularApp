﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.DbModels;
using Microsoft.Extensions.Options;
using WebApplication1.IRepository;
using WebApplication1.Models;
using MongoDB.Driver;

namespace WebApplication1.Repository
{
    public class ProductRepository: IProductRepository
    {
        private readonly ObjectContext _context = null;

        public ProductRepository(IOptions<Settings> settings)
        {
            _context = new ObjectContext(settings);
        }

        public async Task<IEnumerable<Product>> Get()
        {
            return await _context.Products.Find(x => true).ToListAsync();
        }

        public async Task<Product> Get(string id)
        {
            var product = Builders<Product>.Filter.Eq("Id", id);
            return await _context.Products.Find(product).FirstOrDefaultAsync();
        }

        public async Task Add(Product product)
        {
            await _context.Products.InsertOneAsync(product);
        }
    }
}
